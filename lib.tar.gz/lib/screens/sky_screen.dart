import 'dart:async';

import 'package:flutter/material.dart';

import '../models/constellation.dart';
import '../models/device_orientation.dart' as sky;
import '../models/observer_location.dart';
import '../models/sky_star.dart';
import '../services/constellation_service.dart';
import '../services/location_service.dart';
import '../services/orientation_service.dart';
import '../services/star_catalog_service.dart';
import '../widgets/star_debug_painter.dart';

class SkyScreen extends StatefulWidget {
  const SkyScreen({super.key});

  @override
  State<SkyScreen> createState() => _SkyScreenState();
}

class _SkyScreenState extends State<SkyScreen> {
  final OrientationService _orientationService =
      OrientationService();

  final LocationService _locationService =
      LocationService();

  final StarCatalogService _starCatalogService =
      StarCatalogService();

  final ConstellationService _constellationService =
      ConstellationService();

  StreamSubscription<sky.DeviceOrientation>?
      _orientationSubscription;

  sky.DeviceOrientation? _orientation;

  ObserverLocation? _location;

  List<SkyStar> _stars = [];
  List<Constellation> _constellations = [];

  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();

    _load();
  }

  Future<void> _load() async {
    try {
      final stars =
          await _starCatalogService.loadStars();

      final constellations =
          await _constellationService
              .loadConstellations();

      final location =
          await _locationService
              .getCurrentLocation();

      if (!mounted) {
        return;
      }

      setState(() {
        _stars = stars;
        _constellations = constellations;
        _location = location;
        _loading = false;
      });

      _orientationSubscription =
          _orientationService.orientationStream.listen(
        _handleOrientation,
      );

      _orientationService.start();
    } catch (error) {
      if (!mounted) {
        return;
      }

      setState(() {
        _loading = false;
        _error = error.toString();
      });
    }
  }

  void _handleOrientation(
    sky.DeviceOrientation orientation,
  ) {
    if (!mounted) {
      return;
    }

    setState(() {
      _orientation = orientation;
    });
  }

  @override
  void dispose() {
    _orientationSubscription?.cancel();
    _orientationService.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    if (_error != null) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Text(
              _error!,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white70,
              ),
            ),
          ),
        ),
      );
    }

    final orientation = _orientation;
    final location = _location;

    if (orientation == null ||
        location == null) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Text(
            'Waiting for sensors...',
            style: TextStyle(
              color: Colors.white70,
            ),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: CustomPaint(
          painter: StarDebugPainter(
            orientation: orientation,
            stars: _stars,
            constellations: _constellations,
            latitude: location.latitude,
            longitude: location.longitude,
            utc: DateTime.now().toUtc(),
          ),
          child: const SizedBox.expand(),
        ),
      ),
    );
  }
}