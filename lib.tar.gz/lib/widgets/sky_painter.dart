import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../models/device_orientation.dart';
import '../models/sky_star.dart';

class SkyPainter extends CustomPainter {
  const SkyPainter({
    required this.stars,
    required this.orientation,
    this.showHorizon = true,
    this.showConstellations = true,
  });

  final List<SkyStar> stars;
  final DeviceOrientation orientation;

  final bool showHorizon;
  final bool showConstellations;

  // Full 360° horizontal sky.
  //
  // The vertical axis covers the visible hemisphere from
  // horizon to zenith.
  static const verticalFov = 180.0;

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    _drawBackground(canvas, size);

    final buckets =
        <_StarBucket, List<Offset>>{};

    for (final star in stars) {
      final position = _projectStar(
        star,
        size,
      );

      if (position == null) {
        continue;
      }

      final bucket = _StarBucket(
        color: _starColor(
          star.spectralType,
        ),
        pointSize:
            _quantizeRadius(
              star.magnitude,
            ) *
            2,
      );

      (buckets[bucket] ??= []).add(position);
    }

    for (final entry in buckets.entries) {
      final paint = Paint()
        ..color = entry.key.color
        ..strokeWidth = entry.key.pointSize
        ..strokeCap = StrokeCap.round;

      canvas.drawPoints(
        ui.PointMode.points,
        entry.value,
        paint,
      );
    }

    if (showHorizon) {
      _drawHorizon(
        canvas,
        size,
      );
    }

    // Constellation rendering will be added here
    // once the current constellation model is wired
    // into this painter.
    if (showConstellations) {
      // _drawConstellations(canvas, size);
    }
  }

  Offset? _projectStar(
    SkyStar star,
    Size size,
  ) {
    // Stars at or below the astronomical horizon
    // are not visible.
    if (star.altitude <= 0) {
      return null;
    }

    final horizontalDifference =
        _angularDifference(
      star.azimuth,
      orientation.heading,
    );

    // Full 360° horizontal projection.
    //
    // This keeps the 0° / 360° transition continuous
    // and allows the complete azimuth circle to be
    // explored by rotating the phone.
    final x =
        (horizontalDifference + 180) /
            360 *
            size.width;

    // Pitch convention:
    //
    // +90 = pointing up
    //   0 = horizon
    // -90 = pointing down
    //
    // When the phone points up, the horizon moves down.
    // When the phone points down, the horizon moves up.
    final verticalDifference =
        star.altitude -
        orientation.pitch;

    final y =
        size.height / 2 -
        (verticalDifference /
                verticalFov) *
            size.height;

    // Keep drawing bounded to the current screen.
    if (x < -2 ||
        x > size.width + 2 ||
        y < -2 ||
        y > size.height + 2) {
      return null;
    }

    return Offset(x, y);
  }

  double _angularDifference(
    double angle,
    double reference,
  ) {
    return ((angle - reference + 540) % 360) -
        180;
  }

  double _quantizeRadius(
    double magnitude,
  ) {
    return (_starRadius(magnitude) * 4)
            .round() /
        4;
  }

  double _starRadius(
    double magnitude,
  ) {
    final radius =
        4.5 - magnitude * 0.55;

    return radius.clamp(
      0.8,
      4.5,
    );
  }

  Color _starColor(
    String? spectralType,
  ) {
    if (spectralType == null ||
        spectralType.isEmpty) {
      return Colors.white;
    }

    switch (
        spectralType[0].toUpperCase()) {
      case 'O':
        return const Color(0xFF9BB0FF);

      case 'B':
        return const Color(0xFFAABFFF);

      case 'A':
        return const Color(0xFFCAD8FF);

      case 'F':
        return const Color(0xFFF8F7FF);

      case 'G':
        return const Color(0xFFFFF4EA);

      case 'K':
        return const Color(0xFFFFD2A1);

      case 'M':
        return const Color(0xFFFFCC6F);

      default:
        return Colors.white;
    }
  }

  void _drawHorizon(
    Canvas canvas,
    Size size,
  ) {
    // Altitude 0° is the astronomical horizon.
    //
    // Roll is intentionally ignored here so that the
    // horizon remains horizontal on screen.
    final horizonY =
        size.height / 2 +
        (orientation.pitch /
                verticalFov) *
            size.height;

    if (horizonY < -20 ||
        horizonY >
            size.height + 20) {
      return;
    }

    final linePaint = Paint()
      ..color =
          Colors.greenAccent.withValues(
        alpha: 0.8,
      )
      ..strokeWidth = 1.5;

    canvas.drawLine(
      Offset(0, horizonY),
      Offset(size.width, horizonY),
      linePaint,
    );

    final markerPaint = Paint()
      ..color =
          Colors.greenAccent.withValues(
        alpha: 0.8,
      )
      ..strokeWidth = 1.0;

    canvas.drawLine(
      Offset(
        size.width / 2,
        horizonY - 6,
      ),
      Offset(
        size.width / 2,
        horizonY + 6,
      ),
      markerPaint,
    );

    final textPainter = TextPainter(
      text: const TextSpan(
        text: 'HORIZON',
        style: TextStyle(
          color: Colors.greenAccent,
          fontSize: 11,
          fontWeight: FontWeight.w500,
          letterSpacing: 1.2,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();

    textPainter.paint(
      canvas,
      Offset(
        (size.width -
                textPainter.width) /
            2,
        horizonY -
            textPainter.height -
            7,
      ),
    );
  }

  void _drawBackground(
    Canvas canvas,
    Size size,
  ) {
    final paint = Paint()
      ..color = Colors.black;

    canvas.drawRect(
      Offset.zero & size,
      paint,
    );
  }

  @override
  bool shouldRepaint(
    covariant SkyPainter oldDelegate,
  ) {
    return oldDelegate.stars != stars ||
        oldDelegate.orientation !=
            orientation ||
        oldDelegate.showHorizon !=
            showHorizon ||
        oldDelegate.showConstellations !=
            showConstellations;
  }
}

class _StarBucket {
  const _StarBucket({
    required this.color,
    required this.pointSize,
  });

  final Color color;
  final double pointSize;

  @override
  bool operator ==(Object other) {
    return other is _StarBucket &&
        other.color == color &&
        other.pointSize == pointSize;
  }

  @override
  int get hashCode =>
      Object.hash(
        color,
        pointSize,
      );
}