import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../blocs/sky/sky_bloc.dart';
import '../blocs/sky/sky_event.dart';
import '../blocs/sky/sky_state.dart';

class SkyDock extends StatelessWidget {
  const SkyDock({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocSelector<SkyBloc, SkyState, _DockState>(
      selector: (state) => _DockState(
        showHorizon: state.showHorizon,
        showConstellations:
            state.showConstellations,
        objectSelectionEnabled:
            state.objectSelectionEnabled,
      ),
      builder: (context, dockState) {
        return DecoratedBox(
          decoration: BoxDecoration(
            color: Colors.black.withValues(
              alpha: 0.72,
            ),
            border: Border.all(
              color: Colors.white.withValues(
                alpha: 0.14,
              ),
              width: 1,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 6,
              vertical: 5,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _DockToggle(
                  label: 'HL',
                  active: dockState.showHorizon,
                  onTap: () {
                    context.read<SkyBloc>().add(
                          const SkyHorizonToggled(),
                        );
                  },
                ),
                _DockToggle(
                  label: 'CONST',
                  active:
                      dockState.showConstellations,
                  onTap: () {
                    context.read<SkyBloc>().add(
                          const SkyConstellationsToggled(),
                        );
                  },
                ),
                _DockToggle(
                  label: 'OBJ',
                  active:
                      dockState.objectSelectionEnabled,
                  onTap: () {
                    context.read<SkyBloc>().add(
                          const SkyObjectSelectionToggled(),
                        );
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _DockToggle extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _DockToggle({
    required this.label,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    const accent = Color.fromARGB(
      255,
      94,
      139,
      118,
    );

    return Semantics(
      button: true,
      toggled: active,
      label: label,
      child: InkWell(
        onTap: onTap,
        splashColor: Colors.transparent,
        highlightColor: Colors.white.withValues(
          alpha: 0.04,
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 11,
            vertical: 6,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                label,
                style: TextStyle(
                  color: active
                      ? Colors.white
                      : Colors.white54,
                  fontSize: 9,
                  fontWeight: FontWeight.w500,
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(height: 4),
              AnimatedContainer(
                duration:
                    const Duration(milliseconds: 160),
                width: 18,
                height: 2,
                color: active
                    ? accent
                    : Colors.white24,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DockState {
  final bool showHorizon;
  final bool showConstellations;
  final bool objectSelectionEnabled;

  const _DockState({
    required this.showHorizon,
    required this.showConstellations,
    required this.objectSelectionEnabled,
  });
}