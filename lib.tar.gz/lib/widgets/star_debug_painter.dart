import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../astronomy/coordinate_converter.dart';
import '../astronomy/sky_coordinates.dart';
import '../models/constellation.dart';
import '../models/device_orientation.dart';
import '../models/sky_star.dart';

class StarDebugPainter extends CustomPainter {
  final DeviceOrientation orientation;

  final List<SkyStar> stars;
  final List<Constellation> constellations;

  final double latitude;
  final double longitude;

  final DateTime utc;

  StarDebugPainter({
    required this.orientation,
    required this.stars,
    required this.constellations,
    required this.latitude,
    required this.longitude,
    required this.utc,
  });

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    final center = Offset(
      size.width / 2,
      size.height / 2,
    );

    /*
     * Calculate the screen position of every star
     * once.
     *
     * These positions are reused by:
     *
     * - star rendering
     * - constellation rendering
     */
    final starPositions =
        _calculateStarPositions(
      center: center,
      size: size,
    );

    _drawStars(
      canvas,
      starPositions,
    );

    _drawConstellations(
      canvas,
      starPositions,
    );

    _drawHorizon(
      canvas,
      size,
      center,
    );

    _drawCenterMarker(
      canvas,
      center,
    );
  }

  // ---------------------------------------------------------------------------
  // Star positions
  // ---------------------------------------------------------------------------

  Map<int, Offset> _calculateStarPositions({
    required Offset center,
    required Size size,
  }) {
    final positions = <int, Offset>{};

    for (final star in stars) {
      final horizontal =
          CoordinateConverter.starToHorizontal(
        star: star,
        latitude: latitude,
        longitude: longitude,
        utc: utc,
      );

      final world =
          SkyCoordinates.horizontalToVector(
        azimuth: horizontal.azimuth,
        altitude: horizontal.altitude,
      );

      final point = _project(
        world: world,
        center: center,
        size: size,
      );

      if (point == null) {
        continue;
      }

      positions[star.id] = point;
    }

    return positions;
  }

  // ---------------------------------------------------------------------------
  // Projection
  // ---------------------------------------------------------------------------

  Offset? _project({
    required List<double> world,
    required Offset center,
    required Size size,
  }) {
    final worldX = world[0];
    final worldY = world[1];
    final worldZ = world[2];

    final screenX =
        worldX * orientation.rightX +
        worldY * orientation.rightY +
        worldZ * orientation.rightZ;

    final screenY =
        worldX * orientation.upX +
        worldY * orientation.upY +
        worldZ * orientation.upZ;

    final depth =
        worldX * orientation.backX +
        worldY * orientation.backY +
        worldZ * orientation.backZ;

    /*
     * The celestial object is behind
     * the phone.
     */
    if (depth <= 0) {
      return null;
    }

    final focalLength =
        size.height * 0.5;

    final x =
        center.dx +
        focalLength *
            screenX /
            depth;

    final y =
        center.dy -
        focalLength *
            screenY /
            depth;

    /*
     * Don't keep points that are far
     * outside the visible canvas.
     */
    if (x < -50 ||
        x > size.width + 50 ||
        y < -50 ||
        y > size.height + 50) {
      return null;
    }

    return Offset(x, y);
  }

  // ---------------------------------------------------------------------------
  // Stars
  // ---------------------------------------------------------------------------

  void _drawStars(
    Canvas canvas,
    Map<int, Offset> positions,
  ) {
    final paint = Paint()
      ..style = PaintingStyle.fill;

    for (final star in stars) {
      final position =
          positions[star.id];

      if (position == null) {
        continue;
      }

      paint.color =
          _colorForSpectralType(
        star.spectralType,
      );

      final radius =
          _radiusForMagnitude(
        star.magnitude,
      );

      canvas.drawCircle(
        position,
        radius,
        paint,
      );
    }
  }

  double _radiusForMagnitude(
    double magnitude,
  ) {
    /*
     * Brighter stars are larger.
     */
    final radius =
        2.8 -
        magnitude * 0.32;

    return radius.clamp(
      0.7,
      2.8,
    );
  }

  Color _colorForSpectralType(
    String? spectralType,
  ) {
    if (spectralType == null ||
        spectralType.isEmpty) {
      return Colors.white;
    }

    final type =
        spectralType.trim().toUpperCase();

    if (type.isEmpty) {
      return Colors.white;
    }

    switch (type[0]) {
      case 'O':
        return const Color(0xFF9BB0FF);

      case 'B':
        return const Color(0xFFAABFFF);

      case 'A':
        return const Color(0xFFCAD8FF);

      case 'F':
        return const Color(0xFFF8F7FF);

      case 'G':
        return const Color(0xFFFFF4EA);

      case 'K':
        return const Color(0xFFFFD2A1);

      case 'M':
        return const Color(0xFFFFCC6F);

      default:
        return Colors.white;
    }
  }

  // ---------------------------------------------------------------------------
  // Constellations
  // ---------------------------------------------------------------------------

  void _drawConstellations(
    Canvas canvas,
    Map<int, Offset> positions,
  ) {
    final paint = Paint()
      ..color = Colors.white24
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;

    for (final constellation
        in constellations) {
      for (final line
          in constellation.lines) {
        if (line.length < 2) {
          continue;
        }

        for (var i = 0;
            i < line.length - 1;
            i++) {
          final first =
              positions[line[i]];

          final second =
              positions[line[i + 1]];

          if (first == null ||
              second == null) {
            continue;
          }

          canvas.drawLine(
            first,
            second,
            paint,
          );
        }
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Horizon
  // ---------------------------------------------------------------------------

  void _drawHorizon(
    Canvas canvas,
    Size size,
    Offset center,
  ) {
    final points = <Offset>[];

    /*
     * The horizon is altitude = 0°.
     *
     * We sample it around the entire
     * celestial sphere.
     */
    for (var azimuth = 0.0;
        azimuth <= 360.0;
        azimuth += 2.0) {
      final world =
          SkyCoordinates.horizontalToVector(
        azimuth: azimuth,
        altitude: 0,
      );

      final point = _project(
        world: world,
        center: center,
        size: size,
      );

      if (point != null) {
        points.add(point);
      }
    }

    if (points.length < 2) {
      return;
    }

    final paint = Paint()
      ..color = Colors.white38
      ..strokeWidth = 1.2
      ..style = PaintingStyle.stroke;

    final path = Path();

    path.moveTo(
      points.first.dx,
      points.first.dy,
    );

    for (var i = 1;
        i < points.length;
        i++) {
      path.lineTo(
        points[i].dx,
        points[i].dy,
      );
    }

    canvas.drawPath(
      path,
      paint,
    );
  }

  // ---------------------------------------------------------------------------
  // Center marker
  // ---------------------------------------------------------------------------

  void _drawCenterMarker(
    Canvas canvas,
    Offset center,
  ) {
    final paint = Paint()
      ..color = Colors.white24
      ..strokeWidth = 1;

    canvas.drawLine(
      Offset(
        center.dx - 8,
        center.dy,
      ),
      Offset(
        center.dx + 8,
        center.dy,
      ),
      paint,
    );

    canvas.drawLine(
      Offset(
        center.dx,
        center.dy - 8,
      ),
      Offset(
        center.dx,
        center.dy + 8,
      ),
      paint,
    );
  }

  @override
  bool shouldRepaint(
    StarDebugPainter oldDelegate,
  ) {
    return oldDelegate.orientation !=
            orientation ||
        oldDelegate.stars != stars ||
        oldDelegate.constellations !=
            constellations ||
        oldDelegate.latitude !=
            latitude ||
        oldDelegate.longitude !=
            longitude ||
        oldDelegate.utc != utc;
  }
}