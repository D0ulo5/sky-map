import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/device_orientation.dart';

class HorizonPainter extends CustomPainter {
  final DeviceOrientation orientation;

  HorizonPainter({
    required this.orientation,
  });

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    final center = Offset(
      size.width / 2,
      size.height / 2,
    );

    final points = <Offset>[];

    /*
     * Horizon:
     *
     * altitude = 0°
     * azimuth = 0..360°
     */
    for (var azimuth = 0.0;
        azimuth <= 360.0;
        azimuth += 1.0) {
      final point = _project(
        azimuth: azimuth,
        center: center,
        size: size,
      );

      if (point != null) {
        points.add(point);
      }
    }

    if (points.length < 2) {
      return;
    }

    final paint = Paint()
      ..color = Colors.white54
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    final path = Path();

    path.moveTo(
      points.first.dx,
      points.first.dy,
    );

    for (var i = 1; i < points.length; i++) {
      path.lineTo(
        points[i].dx,
        points[i].dy,
      );
    }

    canvas.drawPath(
      path,
      paint,
    );

    _drawCenterMarker(
      canvas,
      center,
    );
  }

  Offset? _project({
    required double azimuth,
    required Offset center,
    required Size size,
  }) {
    final radians =
        azimuth * math.pi / 180;

    /*
     * World coordinate:
     *
     * X = North
     * Y = East
     * Z = Up
     *
     * Horizon means Z = 0.
     */
    final worldX = math.cos(radians);
    final worldY = math.sin(radians);
    const worldZ = 0.0;

    /*
     * Camera basis.
     *
     * BACK = viewing direction
     * RIGHT = screen right
     * UP = screen up
     */
    final backX = orientation.backX;
    final backY = orientation.backY;
    final backZ = orientation.backZ;

    final rightX = orientation.rightX;
    final rightY = orientation.rightY;
    final rightZ = orientation.rightZ;

    final upX = orientation.upX;
    final upY = orientation.upY;
    final upZ = orientation.upZ;

    /*
     * Transform world direction into camera space.
     */
    final screenX =
        worldX * rightX +
        worldY * rightY +
        worldZ * rightZ;

    final screenY =
        worldX * upX +
        worldY * upY +
        worldZ * upZ;

    final depth =
        worldX * backX +
        worldY * backY +
        worldZ * backZ;

    /*
     * Don't draw points behind the phone.
     */
    if (depth <= 0) {
      return null;
    }

    /*
     * Perspective projection.
     */
    final focalLength =
        size.height * 0.5;

    final x =
        center.dx +
        focalLength * screenX / depth;

    /*
     * Flutter's Y axis points downward.
     *
     * Our UP vector points upward.
     */
    final y =
        center.dy -
        focalLength * screenY / depth;

    return Offset(x, y);
  }

  void _drawCenterMarker(
    Canvas canvas,
    Offset center,
  ) {
    final paint = Paint()
      ..color = Colors.white38
      ..strokeWidth = 1;

    canvas.drawLine(
      Offset(
        center.dx - 8,
        center.dy,
      ),
      Offset(
        center.dx + 8,
        center.dy,
      ),
      paint,
    );

    canvas.drawLine(
      Offset(
        center.dx,
        center.dy - 8,
      ),
      Offset(
        center.dx,
        center.dy + 8,
      ),
      paint,
    );
  }

  @override
  bool shouldRepaint(
    HorizonPainter oldDelegate,
  ) {
    return oldDelegate.orientation != orientation;
  }
}